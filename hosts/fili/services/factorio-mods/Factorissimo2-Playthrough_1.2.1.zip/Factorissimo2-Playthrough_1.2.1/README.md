# factorissimo2-inception
Factorissimo2 Inception - Factorio mod

A mod that spawns you in a [Factorissimo2](https://mods.factorio.com/mod/Factorissimo2) factory, from which you cannot leave.

Contributions are welcome!
