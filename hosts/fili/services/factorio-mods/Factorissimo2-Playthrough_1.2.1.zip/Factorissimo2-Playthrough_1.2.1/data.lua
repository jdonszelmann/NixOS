require("prototypes.inputcombinator")
require("prototypes.styles")

require("prototypes.technology.water")

require("prototypes.map-gen-preset") -- map generation preset
