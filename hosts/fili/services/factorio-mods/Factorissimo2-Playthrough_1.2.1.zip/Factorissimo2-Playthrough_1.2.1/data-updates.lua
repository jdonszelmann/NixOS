require("prototypes.technology.belts")    -- belt research for all mods
require("prototypes.entities.fastloader") -- fastest loader for all mods
